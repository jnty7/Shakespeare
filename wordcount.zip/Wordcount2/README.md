# shakespeare_count
simple counting jobs for shakespeare corpus</br>

对莎士比亚语料库处理，输出统计数据：
1. 语料库中唯一（或不同）术语的数量
2. 语料库中以字母T / t开头的单词数
3. 出现少于5次的术语数量
4. 整体读取的文件数
5. 最常出现的5个术语及其词频

项目说明：[莎士比亚数据集处理](https://blog.csdn.net/qq_41733192/article/details/118669539)
